-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 03:06 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jdbcpajakkendaraan`
--

-- --------------------------------------------------------

--
-- Table structure for table `berkaskendaraan`
--

CREATE TABLE `berkaskendaraan` (
  `nama` varchar(50) NOT NULL,
  `nostnk` varchar(50) NOT NULL,
  `nobpkb` varchar(50) NOT NULL,
  `tahunkendaraan` varchar(10) NOT NULL,
  `jeniskendaraan` varchar(50) NOT NULL,
  `merkkendaraan` varchar(50) NOT NULL,
  `denda` text NOT NULL,
  `pajakpokok` text NOT NULL,
  `totalpembayaran` text NOT NULL,
  `bayar` text NOT NULL,
  `kembalian` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berkaskendaraan`
--

INSERT INTO `berkaskendaraan` (`nama`, `nostnk`, `nobpkb`, `tahunkendaraan`, `jeniskendaraan`, `merkkendaraan`, `denda`, `pajakpokok`, `totalpembayaran`, `bayar`, `kembalian`) VALUES
('Setyawan', '1232', '31231', '2018', 'motor', 'eeee', '50450000', '120000', '50700000', '0', '0'),
('kui', '121', '21213', '1', 'motor', 'ww', '50450000', '120000', '50700000', '0', '0'),
('ww', '222', '22', '2017', 'motor', '2222', '50450000', '120000', '50700000', '0', '0'),
('sadas', '32131', '312', '2018', 'motor', 'honda', '0', '120000', '120000', '0', '0'),
('rrr', '212e', '32212', '33312', 'motor', '3232', '-782350000', '120000', '-782230000', '0', '0'),
('gdfgd', '423423', '2324', '4324', 'motor', '234', '-57650000', '120000', '-57530000', '0', '0'),
('tono', '423423', '2324', '2018', 'motor', '234', '0', '120000', '120000', '0', '0'),
('RAFFY FARHANDY', '672893747', '99999', '2016', 'mobil', 'FERRARI', '1000000', '1000000', '2000000', '2100000.0', '100000.0'),
('tono', '213213', '9999', '2018', 'mobil', 'suzki', '0', '1000000', '1000000', 'null', '0.0'),
('TONO', 'AB 123 YK', '543', '2017', 'motor', 'HARLEY', '25000', '120000', '145000', '150000.0', '5000.0'),
('gigi', 'Ab7896yk', '9999999', '2017', 'motor', 'harley', '25000', '120000', '145000', 'null', '0.0');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `NIK KTP` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`username`, `password`, `NIK KTP`) VALUES
('', '', ''),
('Adrian', '123', '99999'),
('sumi', '333', '99999288948'),
('fathur', '1234', '9990874');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
