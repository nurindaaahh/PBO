
package PROJECTPBO;
public class PROJECTPBO {
    public static void main(String[] args) {
        new viewlogin().setVisible(true);
    }
}
