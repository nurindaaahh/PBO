
package PROJECTPBO;

import java.sql.*;
import java.awt.event.*;
import java.awt.*;

import javax.swing.JOptionPane;
public class controllerberkaskendaraan {
   String DBurl="jdbc:mysql://localhost/jdbcpajakkendaraan";
   String DBusername="root";
   String DBpassword="";
   Connection koneksi;
   Statement statement;
   ResultSet resultSet;
//   viewtampilberkas vtb=new viewtampilberkas();
   public void save(String Nama,String nostnk,String nobpkb,int tahunkendaraan1,String jeniskendaraan,String merkkendaraan,int totaldenda ,int pajakpokok ,int totalpajak,Double bayar,Double kembalian)
   {
       try{   
            Class.forName("com.mysql.jdbc.Driver");
            koneksi =DriverManager.getConnection(DBurl,DBusername,DBpassword);
            statement=koneksi.createStatement();
            statement.executeUpdate("insert into berkaskendaraan values('"+Nama+"','"+nostnk+"','"+nobpkb+"','"+tahunkendaraan1+"','"+jeniskendaraan+"','"+merkkendaraan+"','"+ totaldenda+"','"+pajakpokok+"','"+totalpajak+"','"+bayar+"','"+kembalian+"')");
        
            JOptionPane.showMessageDialog(null,"Data Berhasil Disimpan","HASIL ",JOptionPane.INFORMATION_MESSAGE);
           
            }
        catch(SQLException ex)
            {
                JOptionPane.showMessageDialog(null,"Data tidak ditemukan"+ex,"HASIL ",JOptionPane.ERROR_MESSAGE);
            }
        catch(ClassNotFoundException ex)
    {
        JOptionPane.showMessageDialog(null,"Driver tidak ditemukan"+ex,"HASIL",JOptionPane.ERROR_MESSAGE);
    }
   }
   
   public void cari(String cari)
   {
         try{
       
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl,DBusername,DBpassword);
            statement = koneksi.createStatement();
            String sql = "SELECT * FROM `berkaskendaraan` WHERE `nobpkb`='"+cari+"'";
            resultSet = statement.executeQuery(sql);
            
            if(resultSet.next()){
                if (cari.equals(resultSet.getString("nobpkb"))) {
                   
                         modberkaskendaraan mbk=new modberkaskendaraan();
                         //vtb.setnamapem(resultSet.getString("nama"));
                    mbk.setnamapemilik1(resultSet.getString("nama"));
                    mbk.setnostnk1(resultSet.getString("nostnk"));
                    mbk.setnobpkb(resultSet.getString("nobpkb"));
                    mbk.setcarimerkkendaraan(resultSet.getString("merkkendaraan"));
                    mbk.setcarijeniskendaraan(resultSet.getString("jeniskendaraan"));
                    mbk.setcaritahunkendaraan(resultSet.getString("tahunkendaraan"));
                    String caridenda=resultSet.getString("denda");
                    Double caridenda1=Double.parseDouble(caridenda);
                    mbk.setcaridenda(caridenda1);
                    String caripajakpokok=resultSet.getString("pajakpokok");
                    Double caripajakpokok1=Double.parseDouble(caripajakpokok);
                    mbk.setcaripajakpokok(caripajakpokok1);
                     String caritotalpembayaran=resultSet.getString("totalpembayaran");
                    Double caritotalpembayaran1=Double.parseDouble(caritotalpembayaran);
                    mbk.setcaritotalpajak(caritotalpembayaran1);
                    
                     
                    
                }           
            }else{
                    JOptionPane.showMessageDialog(null, "Data Tidak Ditemukan");
                }
            statement.close();
            koneksi.close();
        }catch(SQLException ex){
             System.out.println("gagal tampil");
        }catch(ClassNotFoundException ex){

        }
   }
  // cbk.update(Unamapem,Unostnk,Unobpkb,Utahunkendaraan1,Umerkkendaraan,Ujeniskendaraan,Udenda1,Upajakpokok1,Utotalpembayaran1,Ubayar1,Ukembalian2);
   public void update(String Unamapem, String Unostnk,String Unobpkb,int Utahunkendaraan1,String Umerkkendaraan, String Ujeniskendaraan,int Udenda1,int Upajakpokok1,int Utotalpembayaran1,Double Ubayar1,Double Ukembalian3)
   {Double bayar1=Ubayar1;Double kembalian=Ukembalian3;
       try
            {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi=DriverManager.getConnection(DBurl,DBusername,DBpassword);  
                      statement=koneksi.createStatement();
               String sql =("UPDATE berkaskendaraan SET nama='"+Unamapem+"',nostnk='"+Unostnk+"',nobpkb='"+Unobpkb+"',tahunkendaraan='"+Utahunkendaraan1+"',jeniskendaraan='"+Ujeniskendaraan+"',merkkendaraan='"+Umerkkendaraan+"',denda='"+Udenda1+"',pajakpokok='"+Upajakpokok1+"',totalpembayaran='"+Utotalpembayaran1+"',bayar='"+bayar1+"',kembalian='"+kembalian+"' WHERE nobpkb='"+Unobpkb+"'");
                System.out.println(">> " + sql);
                 
                statement.executeUpdate(sql);  
                 JOptionPane.showMessageDialog(null,"UPDATE  data sukses");
                
            }
             catch (SQLException ex) {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(null, "GAGAL MEMPERBAHARUI  DATA!"+ex, "Hasil", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver  Tidak Ditemukan!", "Hasil", JOptionPane.ERROR_MESSAGE);
        }
   }
}
