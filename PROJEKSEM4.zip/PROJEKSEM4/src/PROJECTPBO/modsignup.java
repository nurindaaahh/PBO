
package PROJECTPBO;


public class modsignup {
    String username,pass,nik;
    public void setusername(String n)
    {
        this.username=n;
    }
    public void setpassword(String p)
    {
        this.pass=p;
    }
    public void setnik(String k)
    {
        this.nik=k;
    }

    public String getUsername() {
        return username;
    }

    public String getPass() {
        return pass;
    }

    public String getNik() {
        return nik;
    }
    
}
