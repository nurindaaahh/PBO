
package PROJECTPBO;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class viewtampilberkas extends javax.swing.JFrame {
      controllerberkaskendaraan cbk=new controllerberkaskendaraan();
      modpembayaran mp= new modpembayaran();
      int Upajakpokok1,Utotalpembayaran1;
      Double Ubayar1,Ukembalian2,Ukembalian3;
int Utahunkendaraan1;
int Udenda1;
      String nama1;   String Unamapem;
        String Unostnk;
        String Unobpkb;
        String Utahunkendaraan;
        String Umerkkendaraan;
        String Ujeniskendaraan;
        String Udenda;
        String Upajakpokok;
        String Utotalpembayaran;
        String Ubayar;
        String Ukembalian;
    public viewtampilberkas() {
        initComponents();
        setVisible (true);
        setSize(1298,448);
        setLocationRelativeTo(this);
        setTitle("BERKAS DAN PEMBAYARAN");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fcaribpkb9 = new javax.swing.JTextField();
        separator = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        caribpkb = new javax.swing.JLabel();
        btncari = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnbayar = new javax.swing.JButton();
        fkembalian = new javax.swing.JTextField();
        fmerkkendaraan = new javax.swing.JTextField();
        fjeniskendaraan = new javax.swing.JTextField();
        ftahunkendaraan = new javax.swing.JTextField();
        fnostnk = new javax.swing.JTextField();
        fpajakpokok = new javax.swing.JTextField();
        fnamapem = new javax.swing.JTextField();
        ftotalpembayaran = new javax.swing.JTextField();
        fbayar = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        fdenda = new javax.swing.JTextField();
        fcarinobpkb = new javax.swing.JTextField();
        btnback = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        fcaribpkb9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fcaribpkb9ActionPerformed(evt);
            }
        });

        separator.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                separatorFocusLost(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(460, 0, 0, 350);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("TAMPIL BERKAS");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(210, 10, 210, 22);

        caribpkb.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 16)); // NOI18N
        caribpkb.setText("INPUT NO BPKB");
        getContentPane().add(caribpkb);
        caribpkb.setBounds(30, 70, 120, 18);

        btncari.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btncari.setText("cari");
        btncari.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });
        getContentPane().add(btncari);
        btncari.setBounds(470, 69, 70, 30);

        jLabel3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel3.setText("NAMA PEMILIK KENDARAAN");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(30, 110, 220, 20);

        jLabel2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel2.setText("NO STNK");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(30, 150, 80, 20);

        jLabel4.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TAHUN KENDARAAN");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(30, 190, 170, 30);

        jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("JENIS KENDARAAN");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(30, 230, 190, 30);

        jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("MERK KENDARAAN");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(30, 270, 150, 20);

        jLabel7.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("TOTAL PEMBAYARAN");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(700, 160, 170, 20);

        jLabel8.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel8.setText("DENDA");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(760, 60, 100, 20);

        jLabel9.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel9.setText("PAJAK POKOK");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(1020, 60, 120, 20);

        jLabel10.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("KEMBALIAN");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(700, 240, 100, 20);

        jLabel11.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("+");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(930, 110, 30, 26);

        jLabel12.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("BAYAR");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(700, 200, 60, 20);

        btnbayar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnbayar.setText("BAYAR");
        btnbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbayarActionPerformed(evt);
            }
        });
        getContentPane().add(btnbayar);
        btnbayar.setBounds(1150, 200, 90, 27);

        fkembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fkembalianActionPerformed(evt);
            }
        });
        getContentPane().add(fkembalian);
        fkembalian.setBounds(820, 240, 380, 20);

        fmerkkendaraan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fmerkkendaraanActionPerformed(evt);
            }
        });
        getContentPane().add(fmerkkendaraan);
        fmerkkendaraan.setBounds(250, 270, 230, 20);

        fjeniskendaraan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fjeniskendaraanActionPerformed(evt);
            }
        });
        getContentPane().add(fjeniskendaraan);
        fjeniskendaraan.setBounds(250, 230, 230, 20);

        ftahunkendaraan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftahunkendaraanActionPerformed(evt);
            }
        });
        getContentPane().add(ftahunkendaraan);
        ftahunkendaraan.setBounds(250, 190, 230, 20);

        fnostnk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnostnkActionPerformed(evt);
            }
        });
        getContentPane().add(fnostnk);
        fnostnk.setBounds(250, 150, 230, 20);

        fpajakpokok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fpajakpokokActionPerformed(evt);
            }
        });
        getContentPane().add(fpajakpokok);
        fpajakpokok.setBounds(970, 100, 230, 30);

        fnamapem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnamapemActionPerformed(evt);
            }
        });
        getContentPane().add(fnamapem);
        fnamapem.setBounds(250, 110, 230, 20);

        ftotalpembayaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftotalpembayaranActionPerformed(evt);
            }
        });
        getContentPane().add(ftotalpembayaran);
        ftotalpembayaran.setBounds(920, 150, 230, 30);

        fbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbayarActionPerformed(evt);
            }
        });
        getContentPane().add(fbayar);
        fbayar.setBounds(820, 200, 320, 30);

        jLabel13.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("=");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(880, 160, 30, 10);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setText("PEMBAYARAN");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(870, 10, 140, 30);
        getContentPane().add(fdenda);
        fdenda.setBounds(700, 100, 200, 20);
        getContentPane().add(fcarinobpkb);
        fcarinobpkb.setBounds(250, 70, 210, 20);

        btnback.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        btnback.setText("back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        getContentPane().add(btnback);
        btnback.setBounds(10, 360, 93, 29);

        jLabel15.setText("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(0, 40, 1270, 10);

        jLabel16.setText("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(0, 0, 1270, 10);

        jLabel17.setText("jLabel17");
        getContentPane().add(jLabel17);
        jLabel17.setBounds(0, 0, 1300, 450);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fkembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fkembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fkembalianActionPerformed

    private void fmerkkendaraanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fmerkkendaraanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fmerkkendaraanActionPerformed

    private void fjeniskendaraanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fjeniskendaraanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fjeniskendaraanActionPerformed

    private void ftahunkendaraanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftahunkendaraanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftahunkendaraanActionPerformed

    private void fnostnkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnostnkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnostnkActionPerformed

    private void fpajakpokokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fpajakpokokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fpajakpokokActionPerformed

    private void fnamapemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnamapemActionPerformed
       
    }//GEN-LAST:event_fnamapemActionPerformed

    private void ftotalpembayaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftotalpembayaranActionPerformed
   
    }//GEN-LAST:event_ftotalpembayaranActionPerformed

    private void fbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbayarActionPerformed
        
    }//GEN-LAST:event_fbayarActionPerformed

    private void fcaribpkb9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fcaribpkb9ActionPerformed
 
    }//GEN-LAST:event_fcaribpkb9ActionPerformed

    private void separatorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_separatorFocusLost

    }//GEN-LAST:event_separatorFocusLost

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
     
        String caripajakpokok1; String caridenda1;String caritotalpembayaran1;
        String cari=fcarinobpkb.getText();
         if (cari.isEmpty())
         {
             JOptionPane.showMessageDialog(null,"Input no Bpkb terlebih dahulu","INFORMATION",JOptionPane.WARNING_MESSAGE);
         }
         else{
        cbk.cari(cari);
        //getnama();
        modberkaskendaraan mbk=new modberkaskendaraan();
        
        String nama1=mbk.getNama();
        fnamapem.setText(nama1);
       
        fnostnk.setText(mbk.getNostnk());
        ftahunkendaraan.setText(mbk.caritahunkendaraan);
        fmerkkendaraan.setText(mbk.carimerkkendaraan);
        fjeniskendaraan.setText(mbk.carijeniskendaraan);
        Double caridenda0=mbk.getCaridenda();
        caridenda1=caridenda0.toString();
        fdenda.setText(caridenda1);
        
        Double caripajakpokok0=mbk.caripajakpokok;
        
        caripajakpokok1=caripajakpokok0.toString();
        fpajakpokok.setText(caripajakpokok1);
        
        Double caritotalpembayaran0=mbk.caritotalpajak;
        
        caritotalpembayaran1=caritotalpembayaran0.toString();
        ftotalpembayaran.setText(caritotalpembayaran1);
        JOptionPane.showMessageDialog(null, "Data Ditemukan");
        /////////////////////////////////////////////////////////////////
        //U=Update
        /////////////////////////////////
        Unamapem=fnamapem.getText();
         Unostnk=fnostnk.getText();
         Unobpkb=fcarinobpkb.getText();
         Utahunkendaraan=ftahunkendaraan.getText();
         //
                  Utahunkendaraan1= Integer.parseInt(Utahunkendaraan);
        //
                  Umerkkendaraan=fmerkkendaraan.getText();
        Ujeniskendaraan=fjeniskendaraan.getText();
        //
        Udenda=fdenda.getText();
        Udenda1= (int) Double.parseDouble(Udenda);
        //
        Upajakpokok=fpajakpokok.getText();
         Upajakpokok1= (int) Double.parseDouble(Upajakpokok);
        // 
        Utotalpembayaran=ftotalpembayaran.getText();
         Utotalpembayaran1= (int) Double.parseDouble(Utotalpembayaran);
         //
        /////////
        
         } 
        
        
    }//GEN-LAST:event_btncariActionPerformed

    private void btnbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbayarActionPerformed
       Ubayar=fbayar.getText();
        if(Ubayar.isEmpty()) Ubayar1 = 0.0;
        else Ubayar1=Double.parseDouble(Ubayar); 
      if (Ubayar1>Utotalpembayaran1)
      {
     Ukembalian3=Ubayar1-Utotalpembayaran1;
        
        //System.out.println(Ukembalian3);
        //mp.setbayar(Ubayar1);
        Double kembalian=mp.getKembalian(Ubayar1, Utotalpembayaran1);
        String kembalian1=kembalian.toString();
        fkembalian.setText(kembalian1);
        Ukembalian2 = Double.parseDouble(kembalian1);
       // Ukembalian=fkembalian.getText();
        cbk.update(Unamapem,Unostnk,Unobpkb,Utahunkendaraan1,Umerkkendaraan,Ujeniskendaraan,Udenda1,Upajakpokok1,Utotalpembayaran1,Ubayar1,kembalian);
      JOptionPane.showMessageDialog(null, "TERIMAKASIH TELAH MEMBAYAR PAJAK KENDARAAN","PEMBAYARAN",JOptionPane.INFORMATION_MESSAGE);
      }
      else if(Ubayar.isEmpty())
      {
            JOptionPane.showMessageDialog(null, "MASUKAN BERKAS TERLEBIH DAHULU ","PEMBAYARAN",JOptionPane.INFORMATION_MESSAGE);
      }
      else
      {
            JOptionPane.showMessageDialog(null, "MAAF,UANG ANDA TIDAK MENCUKUPI ","PEMBAYARAN",JOptionPane.INFORMATION_MESSAGE);
      }
    }//GEN-LAST:event_btnbayarActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
      
        new viewawal ().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnbackActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewtampilberkas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnbayar;
    private javax.swing.JButton btncari;
    private javax.swing.JLabel caribpkb;
    private javax.swing.JTextField fbayar;
    private javax.swing.JTextField fcaribpkb9;
    private javax.swing.JTextField fcarinobpkb;
    private javax.swing.JTextField fdenda;
    private javax.swing.JTextField fjeniskendaraan;
    private javax.swing.JTextField fkembalian;
    private javax.swing.JTextField fmerkkendaraan;
    private javax.swing.JTextField fnamapem;
    private javax.swing.JTextField fnostnk;
    private javax.swing.JTextField fpajakpokok;
    private javax.swing.JTextField ftahunkendaraan;
    private javax.swing.JTextField ftotalpembayaran;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator separator;
    // End of variables declaration//GEN-END:variables

    public JTextField getnama()
    {
      return fnamapem;
    }
    void setnamapem(String nama)
    {
        this.nama1=nama;
        fnamapem.setText(nama1);
    }
            
}
