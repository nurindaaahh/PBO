
package PROJECTPBO;


public class modpemmotor extends modpembayaran implements modinterfacepemmotor {
//int pajak1,pajak5;
  
    modpemmotor()
 {
     setdenda(denda);
     sethitungpajak1(pajak1);
     setpajakpokok(pajak1);
    // sethitungpajak5(pajak5);
 }
    

}
