
package PROJECTPBO;
public class viewsignup extends javax.swing.JFrame {
controllersignup cs=new controllersignup();
  
    public viewsignup() {
        initComponents();
        setVisible(true);
        setSize(370,308);
        setLocationRelativeTo(this);
        setTitle("SIGN UP");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Sfusername = new javax.swing.JTextField();
        Sfpass = new javax.swing.JTextField();
        Sfnik = new javax.swing.JTextField();
        btnsignup = new javax.swing.JButton();
        btnback = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("SIGN UP");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(150, 30, 90, 14);

        jLabel2.setText("=========================================");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 50, 380, 14);

        jLabel3.setText("Username");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 80, 90, 14);

        jLabel4.setText("Password");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 120, 46, 14);

        jLabel5.setText("NIK KTP");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 160, 38, 14);
        getContentPane().add(Sfusername);
        Sfusername.setBounds(160, 80, 180, 20);
        getContentPane().add(Sfpass);
        Sfpass.setBounds(160, 120, 180, 20);
        getContentPane().add(Sfnik);
        Sfnik.setBounds(160, 160, 180, 20);

        btnsignup.setText("SIGNUP");
        btnsignup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsignupActionPerformed(evt);
            }
        });
        getContentPane().add(btnsignup);
        btnsignup.setBounds(110, 220, 93, 23);

        btnback.setText("Back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        getContentPane().add(btnback);
        btnback.setBounds(10, 10, 80, 23);
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 360, 290);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
      dispose();
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnsignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsignupActionPerformed
      String username=Sfusername.getText();
      String pass=Sfpass.getText();
      String nik=Sfnik.getText();
      cs.signup(username, pass, nik);
    }//GEN-LAST:event_btnsignupActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewsignup().setVisible(true);
            }
        });
       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Sfnik;
    private javax.swing.JTextField Sfpass;
    private javax.swing.JTextField Sfusername;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnsignup;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
