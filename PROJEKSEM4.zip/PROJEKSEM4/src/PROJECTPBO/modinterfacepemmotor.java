
package PROJECTPBO;


public interface modinterfacepemmotor {
    public final static int pajak1=120000;
    public final static int pajak5=250000;
    public final static int denda=25000;
    
    
    
}
