
package PROJECTPBO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class controllersignup {
     String DBurl="jdbc:mysql://localhost/jdbcpajakkendaraan";
   String DBusername="root";
   String DBpassword="";
   Connection koneksi;
   Statement statement;
   ResultSet resultSet;

   public void signup(String username,String pass,String nik)
   {
       try{   
            Class.forName("com.mysql.jdbc.Driver");
            koneksi =DriverManager.getConnection(DBurl,DBusername,DBpassword);
            statement=koneksi.createStatement();
            statement.executeUpdate("insert into signup values('"+username+"','"+pass+"','"+nik+"')");
        
            JOptionPane.showMessageDialog(null,"Data Berhasil Disimpan","HASIL ",JOptionPane.INFORMATION_MESSAGE);
           
            }
        catch(SQLException ex)
            {
                JOptionPane.showMessageDialog(null,"Data tidak ditemukan"+ex,"HASIL ",JOptionPane.ERROR_MESSAGE);
            }
        catch(ClassNotFoundException ex)
    {
        JOptionPane.showMessageDialog(null,"Driver tidak ditemukan"+ex,"HASIL",JOptionPane.ERROR_MESSAGE);
    }
   }
   
    public void cari(String username,String pass)
   { try{
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl,DBusername,DBpassword);
            statement = koneksi.createStatement();
            String sql = "SELECT * FROM signup WHERE username='"+username+"' AND password ='"+pass+"'";
            resultSet = statement.executeQuery(sql);
            
            if(resultSet.next()){
                if (username.equals(resultSet.getString("username"))&& pass.equals(resultSet.getString("password"))) {
                    JOptionPane.showMessageDialog(null, "LOGIN BERHASIL ");
                   new viewawal().setVisible(true);}
            }else{
                    JOptionPane.showMessageDialog(null, "GAGAL LOGIN","LOGIN",JOptionPane.ERROR_MESSAGE);
                    JOptionPane.showMessageDialog(null, "SIGN UP TERLEBIH DAHULU","INFORMATION " , JOptionPane.ERROR_MESSAGE);
                }
            
           
        }catch(SQLException ex){
                              JOptionPane.showMessageDialog(null, "JDBC BELUM AKTIF","INFORMATION " , JOptionPane.ERROR_MESSAGE);
                        
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Data Tidak Ditemukan");
        }
}
}
