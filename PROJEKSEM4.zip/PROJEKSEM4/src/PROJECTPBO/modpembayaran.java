
package PROJECTPBO;


public class modpembayaran {
    static int tahunkendaraan;int caridenda,totaldenda,totalpajak,pajakku,dendaku;
    String jeniskendaraan;
    public static Double kembalian,bayar;
    
    public void settahunkendaraan(int tkendaraan)
    {
        tahunkendaraan=tkendaraan;
    }
    
    public void setjeniskendaraan(String jkendaraan)
    {
        this.jeniskendaraan=jkendaraan;
    }

   
    public void setdenda(int denda)
    {
      this.dendaku=denda;
      
    }
    public void setpajakpokok(int pajak1)
    {
        this.pajakku=pajak1;
    }

    public int getPajakku() {
        return pajakku;
    }
    public void sethitungpajak1(int pajak1)
    {
        this.pajakku=pajak1;
       
    }
   
    public void sethitungpajak5(int pajak5)
    {
        totalpajak=totaldenda+pajak5;
    }
    
    
    public void setbayar(double byr)
    {
        bayar=byr;
    }
    
    public void setkembalian()
    {
        kembalian=bayar-totaldenda;
    }
   
     public int getTahunkendaraan() {
        return tahunkendaraan;
    }

    public String getJeniskendaraan() {
        return jeniskendaraan;
    }

    public int getTotaldenda() {
         totaldenda=dendaku*(2018-tahunkendaraan);
        return totaldenda;
    }

    public  static Double getBayar() {
        return bayar;
    }

    public int getTotalpajak() {
         totalpajak=totaldenda+pajakku;
        return totalpajak;
    }

    public Double getKembalian(double bayar, double denda) {
       
        return bayar-denda;
    }
    
    
}
