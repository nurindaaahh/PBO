
package PROJECTPBO;

public interface modinterfacemobil {
    public final static int pajak1=1000000;
    public final static int pajak5=1500000;
    public final static int denda=500000;
}
