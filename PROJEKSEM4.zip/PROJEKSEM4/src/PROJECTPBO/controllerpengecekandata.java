
package PROJECTPBO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class controllerpengecekandata {
    String Dbusername="root";
    String Dbpassword="";
    String Dburl="jdbc:mysql://localhost/jdbcpajakkendaraan";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;
     
    public void hapusData(String hapus){
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(Dburl, Dbusername, Dbpassword);
            String sql="delete from berkaskendaraan where nobpkb='"+hapus+"'";
            PreparedStatement st=koneksi.prepareStatement(sql);
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Delete Data Sukses");
               
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null,"Data gagal disimpan","Hasil",JOptionPane.ERROR_MESSAGE);
        }
        catch(ClassNotFoundException ex)
        {
            JOptionPane.showMessageDialog(null,"Driver Nggak ada","Hasil",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
}
