
package PROJECTPBO;

import javax.swing.JOptionPane;
public class viewawal extends javax.swing.JFrame {
    public viewawal() {
        initComponents();
        setTitle("MENU");
        setSize(410,330);
        setLocationRelativeTo(this);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        INPUTBERKAS = new javax.swing.JButton();
        TAMPILBERKAS = new javax.swing.JButton();
        SELESAI = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        KELUAR = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btncekdata = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        INPUTBERKAS.setBackground(new java.awt.Color(240, 233, 202));
        INPUTBERKAS.setText("INPUT BERKAS");
        INPUTBERKAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INPUTBERKASActionPerformed(evt);
            }
        });
        getContentPane().add(INPUTBERKAS);
        INPUTBERKAS.setBounds(0, 70, 400, 47);

        TAMPILBERKAS.setBackground(new java.awt.Color(240, 237, 205));
        TAMPILBERKAS.setText("TAMPIL BERKAS DAN PEMBAYARAN");
        TAMPILBERKAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TAMPILBERKASActionPerformed(evt);
            }
        });
        getContentPane().add(TAMPILBERKAS);
        TAMPILBERKAS.setBounds(0, 120, 400, 44);

        SELESAI.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 16)); // NOI18N
        SELESAI.setText("SELESAI");
        SELESAI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SELESAIActionPerformed(evt);
            }
        });
        getContentPane().add(SELESAI);
        SELESAI.setBounds(270, 240, 90, 27);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 239, 4));
        jLabel1.setText("SELAMAT DATANG DI POLRES YK");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(60, 0, 290, 20);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 255, 0));
        jLabel2.setText("MENU");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(160, 20, 48, 20);

        KELUAR.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 16)); // NOI18N
        KELUAR.setText("KELUAR");
        KELUAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KELUARActionPerformed(evt);
            }
        });
        getContentPane().add(KELUAR);
        KELUAR.setBounds(30, 240, 90, 27);

        jLabel4.setText("jLabel4");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 220, 400, 0);

        btncekdata.setBackground(new java.awt.Color(240, 240, 211));
        btncekdata.setText("PENGECEKAN DATA");
        btncekdata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncekdataActionPerformed(evt);
            }
        });
        getContentPane().add(btncekdata);
        btncekdata.setBounds(0, 170, 400, 50);
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 0, 400, 300);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void INPUTBERKASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INPUTBERKASActionPerformed
     viewputberkaskendaraan vpberkaskendaraan= new viewputberkaskendaraan();
     dispose();
    }//GEN-LAST:event_INPUTBERKASActionPerformed

    private void TAMPILBERKASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TAMPILBERKASActionPerformed
    viewtampilberkas vtampilberkas=new viewtampilberkas();
    }//GEN-LAST:event_TAMPILBERKASActionPerformed

    private void SELESAIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SELESAIActionPerformed
        JOptionPane.showMessageDialog(null, "TERIMKASIH TELAH MELAKUKAN PEMBAYARAN PAJAK KENDARAAN", "INFORMATION",JOptionPane.INFORMATION_MESSAGE);
     
        int ok=JOptionPane.showConfirmDialog(this,"APAKAH ANDA INGIN KELUAR?","KELUAR",JOptionPane.YES_NO_OPTION);
        if(ok==0)
        {
            dispose();
            setDefaultCloseOperation(3);
        }
    }//GEN-LAST:event_SELESAIActionPerformed

    private void KELUARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KELUARActionPerformed
        int ok=JOptionPane.showConfirmDialog(this,"APAKAH ANDA INGIN KELUAR?","KELUAR",JOptionPane.YES_NO_CANCEL_OPTION);
        if(ok==0)
        {
            dispose();
        }
        
    }//GEN-LAST:event_KELUARActionPerformed

    private void btncekdataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncekdataActionPerformed
  new viewloginkaryawan().setVisible(true);

    }//GEN-LAST:event_btncekdataActionPerformed

    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewawal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton INPUTBERKAS;
    private javax.swing.JButton KELUAR;
    private javax.swing.JButton SELESAI;
    private javax.swing.JButton TAMPILBERKAS;
    private javax.swing.JButton btncekdata;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
