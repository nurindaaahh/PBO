
package PROJECTPBO;

public class modberkaskendaraan {
static String nama,nostnk,nobpkb,carimerkkendaraan,carijeniskendaraan,caritahunkendaraan;
   static double caridenda,caripajakpokok,caritotalpajak;
    /*public void setnamapemilik(String name)
    {
        this.nama=name;
    }

    public void setnostnk(String nstnk)
    {
        this.nostnk=nstnk;
    }

    public void setnobpkb(String nbpkb)
    {
        this.nobpkb=nbpkb;
    }
     public void setcaridenda(double ku)
    {
        this.caridenda=ku;
    }
     public void setcaritahunkendaraan( String i)
     {
         this.caritahunkendaraan=i;
     }
     public void setcaripajakpokok(double ka)
     {
         this.caripajakpokok=ka;
     }
     public void setcarijeniskendaraan(String j)
     {
         this.carijeniskendaraan=j;
     }
     public void setcarimerkkendaraan(String k)
     {
         this.carimerkkendaraan=k;
     }
     public void setcaritotalpajak(double tot)
     {
         this.caritotalpajak=tot;
     }

    public double getCaridenda() {
        return caridenda;
    }

    public double getCaripajakpokok() {
        return caripajakpokok;
    }

    public double getCaritotalpajak() {
        return caritotalpajak;
    }

    public String getNama() {
        return nama;
    }

    public String getNostnk() {
        return nostnk;
    }

    public String getNobpkb() {
        return nobpkb;
    }
*/
   
    
    ////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////
     public void setnamapemilik1(String name)
    {
        nama=name;
    }

    public void setnostnk1(String nstnk)
    {
        nostnk=nstnk;
    }

    public void setnobpkb(String nbpkb)
    {
        nobpkb=nbpkb;
    }
     public void setcaridenda(double ku)
    {
        caridenda=ku;
    }
     public void setcaritahunkendaraan( String i)
     {
         caritahunkendaraan=i;
     }
     public void setcaripajakpokok(double ka)
     {
         caripajakpokok=ka;
     }
     public void setcarijeniskendaraan(String j)
     {
         carijeniskendaraan=j;
     }
     public void setcarimerkkendaraan(String k)
     {
         carimerkkendaraan=k;
     }
     public void setcaritotalpajak(double tot)
     {
         caritotalpajak=tot;
     }

    public static String getNama() {
        return nama;
    }

    public static String getNostnk() {
        return nostnk;
    }

    public static String getNobpkb() {
        return nobpkb;
    }

    public static String getCarimerkkendaraan() {
        return carimerkkendaraan;
    }

    public static String getCarijeniskendaraan() {
        return carijeniskendaraan;
    }

    public static String getCaritahunkendaraan() {
        return caritahunkendaraan;
    }

    public static double getCaridenda() {
        return caridenda;
    }

    public static double getCaripajakpokok() {
        return caripajakpokok;
    }

    public static double getCaritotalpajak() {
        return caritotalpajak;
    }
     
     
}
