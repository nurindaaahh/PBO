
package PROJECTPBO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
public class viewpengecekandata extends JFrame  {
    controllerpengecekandata cpd=new controllerpengecekandata();
    String Tnobpkb;
      String Dbusername="root";
    String Dbpassword="";
    String Dburl="jdbc:mysql://localhost/jdbcpajakkendaraan";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;
    JScrollPane scroll ;
    JTable tabel=new JTable();
    String [][] data = new String[200][11];
    public DefaultTableModel model;
    JButton btndelete= new JButton ("DELETE");
    JButton btnkeluar= new JButton ("KELUAR");
    
    public  viewpengecekandata()
    { tampilData();
        setTitle("PENGECEKAN DATA");
        setLayout(null);
        setSize(1200,1000);
        setVisible (true);
        
        setLocationRelativeTo(this);
         model=new DefaultTableModel(data,new String[]{"NAMA PEMILIK","NOSTNK","NOBPKB","TAHUN KENDARAAN","JENIS KENDARAAN","MERK KENDARAAN","DENDA","PAJAK POKOK","TOTAL PEMBAYARAN","BAYAR","KEMBALIAN"});
        tabel.setModel(model);
        scroll=new JScrollPane(tabel);
        add(scroll).setBounds(130,50,900,700);
        add(btndelete).setBounds(20,110,100,40);
        add(btnkeluar).setBounds(20,50,80,40);
        
        
         
        tabel.addMouseListener(new java.awt.event.MouseAdapter(){ // menambahkan MouseListener pada jTabel
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                 if (e.getClickCount() == 2||e.getClickCount() == 1) {
                     
               // tabel = (JTable)e.getSource();
                int row = tabel.getSelectedRow();
                 Tnobpkb=data[row][2];
               
                
                
                }
                
            }
        });
        
     
        
       btndelete.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                
                cpd.hapusData(Tnobpkb);
                new viewpengecekandata();
            }
        });
        btnkeluar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                new viewawal().setVisible (true);
                dispose();
            }
        });
        
    }
       
     public void tampilData(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(Dburl,Dbusername,Dbpassword);
            statement = koneksi.createStatement();
            String sql = "select * from berkaskendaraan";
            resultSet = statement.executeQuery(sql);
            int p=0;
            while(resultSet.next()){
                data[p][0]=resultSet.getString("nama");
                data[p][1]=resultSet.getString("nostnk");
                data[p][2]=resultSet.getString("nobpkb");
                data[p][3]=resultSet.getString("tahunkendaraan");
                data[p][4]=resultSet.getString("jeniskendaraan");
                data[p][5]=resultSet.getString("merkkendaraan");
                data[p][6]=resultSet.getString("denda");
                data[p][7]=resultSet.getString("pajakpokok");
                data[p][8]=resultSet.getString("totalpembayaran");
                data[p][9]=resultSet.getString("bayar");
                data[p][10]=resultSet.getString("kembalian");
                p++;
            }
            
            statement.close();
            koneksi.close();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Data Gagal Ditampilkan!","Hasil", JOptionPane.ERROR_MESSAGE);
        }catch(ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!","Hasil", JOptionPane.ERROR_MESSAGE);
        }
        
    
    }
    
    
}
